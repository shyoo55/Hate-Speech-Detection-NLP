import re
import string
from tqdm.notebook import tqdm
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize 
from nltk.stem import WordNetLemmatizer 

import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

from section_supervisor import models


def getSentence():
        
    sentences = []
    data = models.Sensitive_Data.objects.all()        
    for d in data :        
        sentences .append(d.content)       
    return sentences

def preprocess(x):
    stop_words = set(stopwords.words('english'))
    lemmatizer = WordNetLemmatizer()
    x = re.sub(r'[' + string.punctuation + ']', '', x)
    x = word_tokenize(x)
    x = ' '.join([_x for _x in [lemmatizer.lemmatize(_x) for _x in x] if _x not in stop_words])
    return x


def bertsim(y):
    x= getSentence()   #Get sentence from dataset

    model = SentenceTransformer('paraphrase-distilroberta-base-v1')
    #sentences = x + [y]
    sentences = [y] + x 
    raw_sentences = sentences
    #sentences = [preprocess(x) for x in sentences]
    sentences = model.encode(sentences, show_progress_bar=True)

    cosine_list = []
    reference_sentence = sentences[0].reshape(1, -1)
    for i in tqdm(range(1, len(raw_sentences)), desc='Compute Similarity'):
        cosine_list.append(cosine_similarity(reference_sentence, sentences[i].reshape(1, -1))[0][0])

    df = pd.DataFrame({
        'sentence': raw_sentences[1:],
        'score': cosine_list
    }).sort_values('score', ascending=True)

    
    #[id,content, score]
    max_value = df ["score"].max()
    #return max_value*100

    list_df= []
    jsonOutput = {}

    #for item in df :
    for index, row in df.iterrows():
        i = float(row['score'])
        if i == max_value:
           jsonOutput['sentence'] = row['sentence']
           jsonOutput['score'] = row['score']
           list_df.append(jsonOutput)
    
    return list_df