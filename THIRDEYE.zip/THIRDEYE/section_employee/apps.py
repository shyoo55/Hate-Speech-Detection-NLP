from django.apps import AppConfig


class SectionUsersConfig(AppConfig):
    name = 'section_employee'
