from django import forms
from django.contrib.auth.models import User
from .validators import validate_file_extension


class MailSend(forms.Form):    
	to_message = forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'form-control clsto_message ' ,'placeholder':'example:employee@thirdetegp.com'}))
	subject_message = forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'form-control clssub_message','placeholder':'subject message'}))
	text_message = forms.CharField(required=True, widget=forms.Textarea(attrs={'class': 'form-control','placeholder':'message'}))
	file = forms.FileField(required=False , validators=[validate_file_extension])


class LoginForm_user(forms.ModelForm):    
    username = forms.CharField(label='User Name',required=True, widget=forms.TextInput(attrs={'class': 'form-control clsto_message'}))
    password = forms.CharField(label='Password',required=True, widget=forms.PasswordInput(attrs={'class': 'form-control clsto_message'}))
    class Meta:
        model = User
        fields = ('username', 'password')