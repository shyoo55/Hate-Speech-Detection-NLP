from django.conf.urls import   include, url
from django.urls import path  
#from django.urls import include
from django.conf.urls.static import  static
from django.contrib.auth import views as auth_views
from django.conf import settings
from section_employee import views as user_view
import notifications.urls
urlpatterns = [
    
     path('index/', user_view.index, name = 'index'),  
     path('', user_view.login_employee, name = 'login'),          
     path('mailsend/', user_view.detectEmail,name='mailsend'),
     path('get_mails_send/', user_view.sentEmail, name='get_mails_send'),
     path('getmails/', user_view.inbox, name='getmails'),	
     path('mailpage/',user_view.inbox,name='mailpage'),        
     url('^inbox/notifications/', include(notifications.urls, namespace='notifications')),
     path('logout/',auth_views.LogoutView.as_view(template_name='section_employee/logout.html') , name='logout'),      
     path('profile/', user_view.profile, name='profile'),
     path('profile_update/', user_view.profile_update, name='profile_update'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)