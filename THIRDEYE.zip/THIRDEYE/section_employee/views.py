from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.conf import settings
from dataset import bert
from notifications.signals import notify
from notifications.models import Notification
from django.contrib.auth import login, authenticate, logout
from random import random
from section_employee import forms
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText #بروتوكول كتابه النص
import smtplib # it is stand for simple mail transfer protocol
import email
import imaplib
import json
import os
from section_supervisor.models import Reports , Sensitive_Data
from django.conf import settings
from datetime import datetime
from users.models import Profile
from email import encoders
import base64
from django.contrib.auth.decorators import login_required 
from users.forms import ProfileUpdateForm  ,UserUpdateForm
from email.mime.base import MIMEBase
import re
regex = '^(\w|\.|\_|\-)+[@]thirdeyegp.com'


# Create your views here.

#function to redirect index the system empolyee..
def index(request):
   context={'title': 'index' }    
   return render(request,'section_employee/index.html',context)
#https://github.com/DarioQuintanilla2109/User-Authentication-Login-Register-Logout-Python-Django-/blob/master/my_site/authenticate/views.py
#function to login the empolyee to system 
def login_employee(request ):
   form = forms.LoginForm_user(request.POST or None)
   context={ 'form':form ,'title': 'Login ' }
   if request.method == 'POST':
      username = request.POST['username']
      password = request.POST['password']        
      user = authenticate(request, username=username, password=password)        
      if user is not None:
         login(request, user)                                 
         ssId = username + str(random())                
         request.session['username']= ssId                     
         return redirect('./index/')
      else:         
         msg  = " Username Or Password  is  incorrect"
         messages.error(request,msg)
         return render(request,'section_employee/login.html',context)                  
   return render(request, "section_employee/login.html", context)
#https://community.esri.com/t5/python-questions/how-to-display-python-results-into-email-body/td-p/641235
#Fucntion initilize the parmeter to send email to gmail by protocl  smtp 
def sendEmail(recipients ,from_message,subject_message, text_message ,file_url , password_gmail):
   body = text_message
   msg = MIMEMultipart()
   msg['Subject'] = subject_message   
   msg['From'] = from_message
   msg['To'] = (', ').join(recipients.split(','))
   msg.attach(MIMEText(body,'plain'))
   print('file_url', file_url)
   if file_url != '' :
      print('file_url', file_url)
      PROJECT_PATH = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..'))
      MEDIA_ROOT = os.path.join(PROJECT_PATH, "media")
      attach_file_name = os.path.join(MEDIA_ROOT, file_url)   #full path to text.  
      print('attach file name', attach_file_name)    
      attach_file = open(attach_file_name, 'rb') # Open the file as binary mode      
      payload = MIMEBase('application', 'octate-stream')
      payload.set_payload((attach_file).read())      
      encoders.encode_base64(payload) #encode the attachment
      #add payload header with filename
      payload.add_header('Content-Decomposition', 'attachment', filename='text.txt')
      msg.attach(payload)


   #Create SMTP session for sending the mail
   server = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
   server.starttls() #enable security
   server.login(from_message, password_gmail)  #login with mail_id and password      
   text = msg.as_string()
   server.sendmail(from_message , recipients, text)
   server.quit()
   print('Mail send')



#function send email and analysis the email and Redirect if have 
#percentage greater than 60 to the supervisor
@login_required
def detectEmail(request):                  
   form_data = forms.MailSend(request.POST or None)
   if request.method == 'POST' :      
      form_send = forms.MailSend(request.POST, request.FILES)
      if form_send.is_valid():
         try:
            test_bert  = ''
            filename = ''
            uploaded_file_url =''         
            
            
            recive_email = form_send.cleaned_data['to_message'] # email reciver
            subject_message = form_send.cleaned_data['subject_message']  
            text_message = form_send.cleaned_data['text_message'] 
 
            
            test_bert = test_bert + subject_message
            test_bert = test_bert + text_message            
            if request.FILES.get('file', False):
               file = request.FILES['file']
               fs = FileSystemStorage()
               filename = fs.save(file.name, file)
               #print ( filename) # New
               uploaded_file_url = fs.url(filename)                         
               #print( uploaded_file_url) # new
               try:         
                  # read file befor send to user and Anylizes
                  PROJECT_PATH = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..'))
                  MEDIA_ROOT = os.path.join(PROJECT_PATH, "media")
                  #str =  open (os.path.join(MEDIA_ROOT,filename),'rb').read()
                  str =  open (os.path.join(MEDIA_ROOT,filename),'r').read()
                  #test_bert = test_bert + str.decode()
                  test_bert = test_bert + str

               except IOError:               
                  print('File not found! ')
  
            print('test bert with file' , test_bert)
            user_id =1 # Supervisor         
            users = User.objects.get(id=request.user.id)                        
            sender_email =users.email         
            sender = User.objects.get(username=request.user)         
            #Get Password Gmail from profile
            user_profile = Profile.objects.all().filter(user_id=users)   
            
            EMAIL = users.email
            password_gmail = user_profile[0].password_gmail
            if not password_gmail :
               return redirect('/profile')         
            sender_username = users.username  
            if (re.search(regex, recive_email)):
               sendEmail(recive_email , sender_email , subject_message , text_message ,filename ,password_gmail)            
            else:                
               #Call Bert AND Test Sentitive data                                
               list_bert  = bert.bertsim(test_bert)
               max_v = list_bert[0] ["score"]*100
               
               #max_v = 65
               #Test of score grater 60 Or Not 
               if( max_v > 60 ):               
                  message = "There is a message has percentage " ,  "{:.2f}".format(max_v)
                  print('message :',message)                                                   
                  recipient = User.objects.get(id=user_id)
                  print('recipient_name' , recipient.email)
                  print(message)            
                  notify.send(sender, recipient=recipient, verb=sender_username, description=message)          
                  print('send notification ')
                  #redirect to admin  (recive email supervisor)
                  sendEmail(recipient.email , sender_email , subject_message , text_message ,filename ,password_gmail)            
                  now = datetime.now()
                  dt_string = now.strftime("%Y-%b-%d %H:%M")
                  print("send to supervisor")
                  notification = Notification.objects.latest('id')
                  print('notification id', notification)
                  #get senitive data id  
                  query_senitive_id  = Sensitive_Data.objects.all().filter(content =list_bert[0]['sentence'] )
                  print (query_senitive_id[0].pk)              
                  #save report to database
                  reports = Reports()
                  reports.similraty_percentage = "{:.2f}".format(max_v)
                  reports.email_sender =   sender_email                   
                  reports.email_reciver =  recive_email
                  reports.sensitive_data_id = query_senitive_id[0].pk
                  reports.spesific_sensitive_data = list_bert[0]['sentence']
                  reports.time_send =dt_string 
                  reports.notification = notification
                  reports.save()         
                  print("save report")
                  #update count sender senitive data               
                  user_profile = Profile.objects.get(user_id=users)   
                  user_profile.count_send_data_Sensitive = user_profile.count_send_data_Sensitive +1                              
                  user_profile.save()
                  print("save count send data Sensitive")


               else:               
                  #redirect to user that message not have senticive data             
                  sendEmail(recive_email , sender_email , subject_message , text_message ,uploaded_file_url ,password_gmail)
                  print("send to user")
         except Exception as ex:
            print (ex)
         return redirect('/index')
   context={ 'form':form_data , }
   return render(request , 'section_employee/Mail_Send.html' , context)

#https://www.thepythoncode.com/article/reading-emails-in-python
#function show inbox email employee  
@login_required
def inbox(request):  
   print('mail page')
   users = User.objects.get(id=request.user.id)                     
   user_profile = Profile.objects.all().filter(user_id=users)      
   EMAIL = users.email
   PASSWORD = user_profile[0].password_gmail
   print(EMAIL)
   print(PASSWORD)
   if not PASSWORD :
      return redirect('/profile')
   SERVER = 'imap.gmail.com'
   mail = object
   mailCount = 0   
   data = []
   ids = []
   idsList = []
   mailinbox = []
   try:
      mail = imaplib.IMAP4_SSL(SERVER ,993)
      mail.login(EMAIL, PASSWORD)
      mail.select('inbox')         
      type, data = mail.search(None, "ALL")
      ids = data[0]
      idsList = ids.split()
      for anEmail in data[0].split():
         jsonOutput = {}
         type, data = mail.fetch(anEmail, '(UID RFC822)')
         raw = data[0][1]
         try:
            raw_str = raw.decode("utf-8")
         except UnicodeDecodeError:
            try:
               raw_str = raw.decode("ISO-8859-1") # ANSI support
            except UnicodeDecodeError:
               try:
                  raw_str = raw.decode("ascii") # ASCII ?
               except UnicodeDecodeError:
                  pass
						
         msg = email.message_from_string(raw_str)
         jsonOutput['subject'] = msg['subject']
         jsonOutput['from'] = msg['from']
         jsonOutput['date'] = msg['date']            
         raw = data[0][0]
         raw_str = raw.decode("utf-8")
         uid = raw_str.split()[2]
         # Body #
         if msg.is_multipart():
            for part in msg.walk():
               partType = part.get_content_type()
               ## Get Body ##
               if partType == "text/plain" and "attachment" not in part:
                  jsonOutput['body'] = part.get_payload()
                  ## Get Attachments ##
                  #if part.get('Content-Disposition') is None:
                     #attchName = part.get_filename()
                     #if bool(attchName):
                        #attchFilePath = str(destFolder)+str(uid)+str("/")+str(attchName)
                        #os.makedirs(os.path.dirname(attchFilePath), exist_ok=True)
                        #with open(attchFilePath, "wb") as f:
                           #f.write(part.get_payload(decode=True))
         else:
            jsonOutput['body'] = msg.get_payload(decode=True).decode("utf-8") # Non-multipart email, perhaps no attachments or just text.
         mailinbox.append(jsonOutput)
   
   except Exception as ex:
      print (ex)
   context={'title':'Show Mail Recive' , 'mailinbox':mailinbox}   
   return render(request,'section_employee/get_mails_inbox.html',context)


#function show email snet by employee 
@login_required
def sentEmail (request):   
   print('mail sent page')     
   users = User.objects.get(id=request.user.id)                     
   user_profile = Profile.objects.all().filter(user_id=users)   
   print(user_profile[0].password_gmail)
   EMAIL = users.email
   PASSWORD = user_profile[0].password_gmail
   if not PASSWORD :
      return redirect('/profile')     
   SERVER = 'imap.gmail.com'
   mail = object   
   mailCount = 0   
   data = []
   ids = []
   idsList = []
   
   mailinbox = []
   try:
      mail = imaplib.IMAP4_SSL(SERVER ,993)
      mail.login(EMAIL, PASSWORD)
      mail.select('"[Gmail]/Sent Mail"')         
      type, data = mail.search(None, "ALL")
      ids = data[0]
      idsList = ids.split()
      for anEmail in data[0].split():
         jsonOutput = {}
         type, data = mail.fetch(anEmail, '(UID RFC822)')
         raw = data[0][1]
         try:
            raw_str = raw.decode("utf-8")
         except UnicodeDecodeError:
            try:
               raw_str = raw.decode("ISO-8859-1") # ANSI support
            except UnicodeDecodeError:
               try:
                  raw_str = raw.decode("ascii") # ASCII ?
               except UnicodeDecodeError:
                  pass
						
         msg = email.message_from_string(raw_str)
         jsonOutput['subject'] = msg['subject']
         jsonOutput['from'] = msg['from']
         jsonOutput['date'] = msg['date']            
         raw = data[0][0]
         raw_str = raw.decode("utf-8")
         uid = raw_str.split()[2]
         # Body #
         if msg.is_multipart():
            for part in msg.walk():
               partType = part.get_content_type()
               ## Get Body ##
               if partType == "text/plain" and "attachment" not in part:
                  jsonOutput['body'] = part.get_payload()
                  ## Get Attachments ##
                  #if part.get('Content-Disposition') is None:
                     #attchName = part.get_filename()
                     #if bool(attchName):
                        #attchFilePath = str(destFolder)+str(uid)+str("/")+str(attchName)
                        #os.makedirs(os.path.dirname(attchFilePath), exist_ok=True)
                        #with open(attchFilePath, "wb") as f:
                           #f.write(part.get_payload(decode=True))
         else:
            jsonOutput['body'] = msg.get_payload(decode=True).decode("utf-8") # Non-multipart email, perhaps no attachments or just text.      
         mailinbox.append(jsonOutput)
      
   except Exception as ex:
      print (ex)  
   
   context={'title':'Show Mail Recive' , 'mailinbox':mailinbox}   
   return render(request,'section_employee/get_mails_send.html',context)



#fucntion make logout employee from system
def logout_employee(request):
    try:
        del request.session['username']
    except:
        pass
    return HttpResponse("<strong>You are logged out.</strong>")

#fucntion show profile employee
@login_required
def profile(request):        
    return render(request, 'section_employee/profile.html')
#https://www.ordinarycoders.com/django-custom-user-profile
#fucntion make update profile employee
@login_required
def profile_update(request):
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileUpdateForm(
            request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid and profile_form.is_valid:
            user_form.save()
            profile_form.save()
            messages.success(
                request, 'finish update profile user')
            return redirect('profile')
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'title': 'update user profile',
        'user_form': user_form,
        'profile_form': profile_form,
    }
    return render(request, 'section_employee/profile_update.html', context)
