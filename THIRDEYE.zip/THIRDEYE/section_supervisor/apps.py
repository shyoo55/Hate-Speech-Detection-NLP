from django.apps import AppConfig


class SectionSupervisorConfig(AppConfig):
    name = 'section_supervisor'
