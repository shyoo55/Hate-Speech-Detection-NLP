from django.db import models
from notifications.models import Notification
from django.utils import timezone
# Create your models here.


class Sensitive_Data(models.Model):
    content = models.TextField()
    def __str__(self):
        return self.content
    


class Reports(models.Model):
    notification = models.ForeignKey(Notification, on_delete=models.CASCADE) # message id
    similraty_percentage = models.FloatField()
    email_sender = models.TextField()
    email_reciver = models.TextField()         
    sensitive_data_id  = models.TextField()
    spesific_sensitive_data = models.TextField()        
    time_send = models.TextField()

    def __str__(self):
        return self.email_sender
        
