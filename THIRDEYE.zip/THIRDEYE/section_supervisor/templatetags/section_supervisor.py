from django import template
import base64
import binascii

register = template.Library()
@register.filter('get_value_from_dict')
def get_value_from_dict(dict_data, key):
    """
    usage example {{ your_dict|get_value_from_dict:your_key }}
    """
    if key:
        return dict_data.get(key)
        #return dict_data[key]


#sregister.filter(get_value_from_dict)
@register.filter('get_value_from_dict_decoder')
def get_value_from_dict_decoder(dict_data , key):
    result =''
    if key:
        body = dict_data.get(key)
        try:
            result = base64.b64decode(body + '=' * (-len(body) % 4))
            #result = base64.b64decode(body)
            return result      
        except binascii.Error:
            print ("no correct base64")
            return body
