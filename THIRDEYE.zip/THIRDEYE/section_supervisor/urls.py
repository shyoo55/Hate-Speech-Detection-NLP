from django.conf.urls import   include, url
from django.urls import path  
from . import views as views_super
from django.contrib.auth import views as auth_views

app_name = 'section_supervisor'

urlpatterns = [
    path('', views_super.login_supervisor, name = 'login'),    
    path('index/',views_super.index, name = 'index'),      
    path('reportsPage/', views_super.reports_page, name = 'reportsPage'),    
    path('make_as_reader/<int:pk>/', views_super.mark_as_reader_notification, name='make_as_reader'),   
    path('show_report/<int:pk>/', views_super.show_report, name = 'show_report'),        
    path('logout/',views_super.logout_supervisor , name='logout'),          
    path('profile/', views_super.profile, name='profile'),
    path('profile_update/', views_super.profile_update, name='profile_update'),
]