from django.shortcuts import render ,redirect ,get_object_or_404
from django.http import HttpResponse , HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth import login, authenticate, logout
from django import forms
from django.contrib.auth.models import User
from django.urls import reverse
from .forms import LoginForm_supervisor
from random import random
from .models import Reports 
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText #بروتوكول كتابه النص
import smtplib # it is stand for simple mail transfer protocol
import email
import imaplib
import json
from datetime import datetime
from users.models import Profile 
from .models import Sensitive_Data
from django.contrib.auth.decorators import login_required 
from users.forms import UserUpdateForm ,ProfileUpdateForm
import base64
import os

# Create your views here.
#https://github.com/DarioQuintanilla2109/User-Authentication-Login-Register-Logout-Python-Django-/blob/master/my_site/authenticate/views.py
#this fuction show the index of system supervisor
@login_required
def index(request):   
   user = User.objects.get(username=request.user)   
   context = {'title':'Supervisor index','user': user }
   return render(request, "section_supervisor/index.html", context)

#this function make the supervisor login to system 
def login_supervisor(request ):
   form = LoginForm_supervisor(request.POST or None)
   context={ 'form':form ,'title': 'Login ' }
   if request.method == 'POST':
      username = request.POST['username']
      password = request.POST['password']        
      user = authenticate(request, username=username, password=password )        
      if user is not None  :         
         login(request, user)                                 
         ssId = username + str(random())         
         request.session['supervisor_id']= ssId                     
         return redirect('./index/')
      else:         
         msg  = " Username Or Password  is  incorrect"
         messages.error(request,msg)
         return render(request,'section_supervisor/login.html',context)                  
   return render(request, "section_supervisor/login.html", context)


#This function show report have notifications
def reports_page(request):
   context = {'title':'Reports Page'} 
   return render(request, "section_supervisor/reports_page.html", context)


#This function  can mute the notification and don't show again
def mark_as_reader_notification(request ,pk):
   print ('the email accepted as sensitive email')
   user = User.objects.get(username=request.user)
   notification= user.notifications.get (id= pk )
   notification.unread = 0
   notification.save()   
   msg  = "the email accepted as sensitive email "
   messages.success(request,msg)
   return render(request ,'section_supervisor/index.html')
#https://community.esri.com/t5/python-questions/how-to-display-python-results-into-email-body/td-p/641235
# Fuction redicrect email to the reciption  message 
def redicrectEmail(recipients ,from_message,subject_message, text_message ,file_url ):   
   user = User.objects.get(email = from_message)   # Get user id for sender
   query_gmail_password = Profile.objects.all().filter(user_id = user)    #get password gmail sender  
   msg = MIMEMultipart()
   msg['Subject'] = subject_message   
   msg['From'] = from_message
   msg['To'] = (', ').join(recipients.split(','))
   msg.attach(MIMEText(text_message,'plain'))
   server = smtplib.SMTP('smtp.gmail.com', 587)
   server.starttls()   
   server.login (from_message , query_gmail_password[0].password_gmail)
   server.send_message(msg)
   server.quit()


'''
Show Report for Notification selected 
The supervisor can redicrect the email 
if have percentage between 60 - 70
and the supervisor can mute the message .
'''
@login_required
def show_report(request,pk):         
   if request.method == 'POST':
      user = User.objects.get(username=request.user)   
      recive_email = request.POST ['tomessage']
      sender_email = request.POST['from_message']
      subject_message = request.POST['subject_message']
      text_message = request.POST['text_message']
      uploaded_file_url = ''        
      redicrectEmail(recive_email , sender_email , subject_message , text_message ,uploaded_file_url)                  
      msg  = "Email sent to user recipient "
      messages.success(request,msg)
      context = {'title':'Supervisor index','user': user }
      return render(request, "section_supervisor/index.html", context)      
   else:
      print('mail page supervisoier ')          
      supervisor = User.objects.get(id=request.user.id)                     
      supervisor_profile = Profile.objects.all().filter(user_id=supervisor)          
      EMAIL = supervisor.email      
      PASSWORD = supervisor_profile[0].password_gmail      
      if not PASSWORD :
         return redirect('/profile')   

      reports = Reports.objects.select_related('notification').all().filter(notification_id=pk)              
      email_sender = ''
      email_reciver= ''
      email_time = ''
      for item in reports :              
         email_sender = item.email_sender
         email_reciver = item.email_reciver      
         email_time = item.time_send        

#https://www.thepythoncode.com/article/reading-emails-in-python
      #Get Email From Gmail     
      SERVER = 'imap.gmail.com'
      mail = object
      data = []
      ids = []
      mailinbox = []
      try:
         mail = imaplib.IMAP4_SSL(SERVER ,993)
         mail.login(EMAIL, PASSWORD)
         mail.select('inbox')         
         type, data = mail.search(None, "ALL")
         ids = data[0]
         idsList = ids.split()
         for anEmail in data[0].split():
            jsonOutput = {}
            type, data = mail.fetch(anEmail, '(UID RFC822)')
            raw = data[0][1]
            try:
               raw_str = raw.decode("utf-8")
            except UnicodeDecodeError:
               try:
                  raw_str = raw.decode("ISO-8859-1") # ANSI support
               except UnicodeDecodeError:
                  try:
                     raw_str = raw.decode("ascii") # ASCII ?
                  except UnicodeDecodeError:
                     pass
                     
            msg = email.message_from_string(raw_str)                                               
            # Now convert to local date-time
            date_tuple = email.utils.parsedate_tz(msg['Date'])
            if date_tuple:
               local_date = datetime.fromtimestamp(email.utils.mktime_tz(date_tuple))               
               email_time_converter =  local_date.strftime("%Y-%b-%d %H:%M")              

            if msg['from'] == email_sender  and  email_time_converter == email_time  :  #sender send message                            
               jsonOutput['from'] = msg['from']
               jsonOutput['subject'] = msg['subject']
               jsonOutput['date'] = msg['date']            
               raw = data[0][0]
               raw_str = raw.decode("utf-8")
               uid = raw_str.split()[2]
               # Body #
               if msg.is_multipart():
                  print('multipart')
                  # iterate over email parts
                  for part in msg.walk():           
                     # extract content type of email       
                     partType = part.get_content_type()                                                                                            
                     ## Get Body ##
                     if partType == "text/plain" and "attachment" not in part:
                        jsonOutput['body'] = part.get_payload()
                        ## Get Attachments ##
                        if part.get('Content-Disposition') is None:
                           attchName = part.get_filename()
                           print('attach name', attchName) #None
                           if bool(attchName):
                              PROJECT_PATH = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..'))
                              MEDIA_ROOT = os.path.join(PROJECT_PATH, "media")
                              attchFilePath = os.path.join(MEDIA_ROOT, attchName)   #full path to text.    
                              os.makedirs(attchFilePath, exist_ok=True)  
                              with open(attchFilePath, "wb") as f:
                                 f.write(part.get_payload(decode=True))
                              #attach_file = open(attach_file_name, 'rb') # Open the file as binary mode     
                              str =  open (attchFilePath,'r').read() 
                              jsonOutput['body'] = jsonOutput['body'] + "\n attachement file \n" + str 
                              #jsonOutput['attchemnt'] = "\n attachement file \n" + str                                                   
               else:                  
                  jsonOutput['body'] = msg.get_payload(decode=True).decode("utf-8") # Non-multipart email, perhaps no attachments or just text.               

               mailinbox.append(jsonOutput)       
      except Exception as ex:
         print (ex)                                     
      print('mailinbox',mailinbox)
      users = User.objects.get(email =email_sender)  
      user_profile = Profile.objects.all().filter(user_id=users)                                   
      count_senitive =  user_profile[0].count_send_data_Sensitive      
      
      context = {'title':'Supervisor index' , 'mailinbox':mailinbox,'pk':pk ,'report':reports  ,'count_senitive':count_senitive}
      return render(request ,'section_supervisor/reports_page.html' ,context)

#For show Profile supervisor
@login_required
def profile(request):        
    return render(request, 'section_supervisor/profile.html')

#https://www.ordinarycoders.com/django-custom-user-profile
#For update Profile supervisor
@login_required
def profile_update(request):
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileUpdateForm(
            request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid and profile_form.is_valid:
            user_form.save()
            profile_form.save()
            messages.success(
                request, 'finish update profile user')
            return redirect('/supervisor/profile')

    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'title': 'update user profile',
        'user_form': user_form,
        'profile_form': profile_form,
    }
    return render(request, 'section_supervisor/profile_update.html', context)

# For Logout supervisor
def logout_supervisor(request):
   try:      
      user = User.objects.get(username=request.user)
      user.session_set.all().delete()
   except:
      pass
   context = {'title': 'logout','logout': 'You have been logged out',}   
   return render(request, 'section_supervisor/logout.html', context)