from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile

class LoginForm(forms.ModelForm):    
    username = forms.CharField(label='User Name',required=True, widget=forms.TextInput(attrs={'class': 'form-control clsto_message'}))
    password = forms.CharField(label='Password', widget=forms.PasswordInput(attrs={'class': 'form-control clsto_message'}))
    class Meta:
        model = User
        fields = ('username', 'password')

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()
    class Meta:
        model = User
        fields = ['first_name', 'username', 'email', 'password1', 'password2']

class UserUpdateForm(forms.ModelForm):
    first_name = forms.CharField(label='first name')
    last_name= forms.CharField(label='last name')
    email = forms.EmailField(label='email')
    password_gmail = forms.CharField(label='Password Gamil login', widget=forms.PasswordInput(attrs={'class': 'form-control clsto_message'}))
     
    class Meta:
        model = User
        fields = ['username','first_name','last_name', 'email']


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']
