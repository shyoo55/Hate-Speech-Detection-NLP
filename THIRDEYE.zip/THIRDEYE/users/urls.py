from django.conf.urls import url
from django.urls import path ,include
from users import views as user_views
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [    
    #path('login/', user_views.login_user, name='login'),
    #path('register/',user_views.register , name='register'),            
    #path('logout/',auth_views.LogoutView.as_view(template_name='users/logout.html') , name='logout'),      
    #path('logout/',user_views.logout_user , name='logout'),      
    #path('profile/', user_views.profile, name='profile'),
    #path('profile_update/', user_views.profile_update, name='profile_update'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)