from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required 
from django.contrib.auth import login, authenticate, logout
from django.http import HttpResponseRedirect ,HttpResponse
from django.contrib import messages
from django.contrib import sessions
from django.utils import timezone
from django import forms
from .forms import LoginForm, UserRegisterForm , UserUpdateForm, ProfileUpdateForm 
from random import random



def login_user(request):
    msg =''
    form = LoginForm(request.POST or None)
    context={ 'form':form ,'title': 'Login ' }
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']        
        user = authenticate(request, username=username, password=password)        
        if user is not None:            
            login(request, user)                        
            if  user.is_superuser :
                ssId = username + str(random())
                print(ssId)
                request.session['supervisor']= ssId            
                return redirect('index')       
            else:
                ssId = username + str(random())
                print(ssId)
                request.session['sessId']= ssId            
                return redirect('index')                        
        else:
            messages.warning(request, 'There is wrong in username or passowrd...')    
            return render(request,'users/login.html',context)
    
    return render(request, 'users/login.html', context)

def register(request):        
    if request.method == 'POST':    	
        form = UserRegisterForm(request.POST)        
        if form.is_valid():
            form.save()
            #username = form.cleaned_data.get('username')
            #request.sessions['username']= username
            messages.success(request, f'Your account has been created! You are now able to log in')            
            return redirect('login')
    else:        
        form = UserRegisterForm()
    return render(request, 'users/register.html', {'form': form})

@login_required
def profile(request):        
    return render(request, 'users/profile.html')

@login_required
def profile_update(request):
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileUpdateForm(
            request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid and profile_form.is_valid:
            user_form.save()
            profile_form.save()
            messages.success(
                request, 'finish update profile user')
            return redirect('profile')
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'title': 'update user profile',
        'user_form': user_form,
        'profile_form': profile_form,
    }
    return render(request, 'users/profile_update.html', context)


def logout_user(request):
    try:
        del request.session['username']
    except:
        pass
    return HttpResponse("<strong>You are logged out.</strong>")